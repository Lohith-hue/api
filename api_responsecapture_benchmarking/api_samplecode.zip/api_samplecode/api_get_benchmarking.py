#!/usr/bin/env python
# coding: utf-8

# # API Response capture

# In[1]:


import requests
import json
import pandas as pd
import geopandas as gpd
import numpy as np
import random
from shapely.geometry import Polygon, Point
#import matplotlib.pyplot as plt
#import contextily as cx


# # Input_values

# In[2]:


input_boundary_filename = 'Singapore.geojson'
coordinates_range = 100
nb_key = 'plaintesting'
tomtom_key = 'T4NeSzdsHG07NmEA7AvH2Jv2IL1s3qUp'
mapbox_accesstoken = 'pk.eyJ1Ijoia2FpLWxpdSIsImEiOiJjazduNmtxcTkwcHlyM2RxNjVqdzBqcmdjIn0.ElP1f3BdnelgeXuRR4Q3BA'


# # Execution

# In[3]:


boundary = gpd.read_file(input_boundary_filename)


# In[4]:


boundary_bounds = boundary.bounds
minx = boundary_bounds.loc[0,'minx']
miny = boundary_bounds.loc[0,'miny']
maxx = boundary_bounds.loc[0,'maxx']
maxy = boundary_bounds.loc[0,'maxy']


# In[5]:


coordinates = []

for each in range(coordinates_range):
    lng = random.uniform(minx, maxx)
    lat = random.uniform(miny, maxy)
    coordinates.append(f"{lat},{lng}")


# In[6]:


origin = coordinates[0:int(len(coordinates)/2)]
destination = coordinates[int(len(coordinates)/2):int(len(coordinates)+1)]


# In[7]:


api_input = pd.DataFrame(origin, columns=['origin'])
api_input['destination'] = destination


# In[ ]:


len(api_input)


# # lat/lng split

# In[8]:


# Create two lists for the loop results to be placed
origin_lat = []
origin_lon = []
destination_lat = []
destination_lon = []

# For each row in a varible,
for index, row in api_input.iterrows():
    origin_lat.append(row['origin'].split(',')[0])
    origin_lon.append(row['origin'].split(',')[1])
    destination_lat.append(row['destination'].split(',')[0])
    destination_lon.append(row['destination'].split(',')[1])
        
api_input['origin_lat'] = origin_lat
api_input['origin_lon'] = origin_lon
api_input['destination_lat'] = destination_lat
api_input['destination_lon'] = destination_lon


# # nb_request_links

# In[9]:


nb_request = []

for index, row in api_input.iterrows():
    nb_request.append(f"https://api.nextbillion.io/directions/json?origin={row['origin_lat']},{row['origin_lon']}&destination={row['destination_lat']},{row['destination_lon']}&key={nb_key}")
    
api_input['nb_request_links'] = nb_request


# # nb_responses

# In[10]:


nb_request_links = api_input['nb_request_links']
nb_response_text = []

for link in nb_request_links:
    nb_response = requests.get(link)
    nb_response_text.append(nb_response.text)
    
api_input['nb_response'] = pd.Series(nb_response_text)


# # tomtom_request_links

# In[11]:


tomtom_request = []

for index, row in api_input.iterrows():
    tomtom_request.append(f"https://api.tomtom.com/routing/1/calculateRoute/{row['origin_lat']},{row['origin_lon']}:{row['destination_lat']},{row['destination_lon']}/json?key={tomtom_key}&travelMode=car")
    
api_input['tomtom_request_links'] = tomtom_request


# # tomtom_responses

# In[12]:


tomtom_request_links = api_input['tomtom_request_links']
tomtom_response_text = []

for link in tomtom_request_links:
    tomtom_response = requests.get(link)
    tomtom_response_text.append(tomtom_response.text)
    
api_input['tomtom_response'] = pd.Series(tomtom_response_text)


# # mapbox_request_links

# In[13]:


mapbox_request = []

for index, row in api_input.iterrows():
    mapbox_request.append(f"https://api.mapbox.com/directions/v5/mapbox/driving/{row['origin_lon']},{row['origin_lat']};{row['destination_lon']},{row['destination_lat']}?access_token={mapbox_accesstoken}&geometries=geojson&alternatives=false")
    
api_input['mapbox_request_links'] = mapbox_request


# # mapbox_responses_links

# In[14]:


mapbox_request_links = api_input['mapbox_request_links']

mapbox_response_text = []

for link in mapbox_request_links:
    mapbox_response = requests.get(link)
    mapbox_response_text.append(mapbox_response.text)
    
api_input['mapbox_response'] = pd.Series(mapbox_response_text)


# # google_request_links

# In[ ]:


#nb_request = []

#for index, row in df.iterrows():
    #nb_request.append(f"https://api.nextbillion.io/directions/json?origin={row['origin_lat']},{row['origin_lon']}&destination={row['destination_lat']},{row['destination_lon']}&key=45bea3792b6e46c1a705f3a8bc3eb33a")
    
#api_input['nb_request_links'] = nb_request


# # google_responses_links

# In[ ]:


#nb_request_links = api_input['nb_request_links']

#nb_response_dict_list = []

#for link in nb_request_links:
    #nb_response = requests.get(link)
    #nb_response_dict_list.append(dict(json.loads(nb_response.text)))
    
#api_input['nb_response_dict'] = pd.Series(nb_response_dict_list)


# # Drop api responses with errors

# In[15]:


api_input = api_input[api_input['nb_response'] != '{"msg":"auth error","status":"401"}']


# In[16]:


api_input = api_input[api_input['tomtom_response'] !='{"formatVersion":"0.0.12","error":{"description":"Engine error while executing route request: NO_ROUTE_FOUND"},"detailedError":{"message":"Engine error while executing route request: NO_ROUTE_FOUND","code":"NO_ROUTE_FOUND"}}']


# In[17]:


api_input = api_input[api_input['mapbox_response'] !='{"code":"NoRoute","message":"No route found","routes":[]}']


# # Distance&Duration

# # nb_distance&duration

# In[18]:


nb_distance = []
nb_duration = []

for index, row in api_input.iterrows():
    nb_response = json.loads(row['nb_response'])
    nb_distance.append(nb_response['routes'][0]['distance'])
    nb_duration.append(nb_response['routes'][0]['duration'])
    
api_input['nb_distance'] = pd.Series(nb_distance)
api_input['nb_duration'] = pd.Series(nb_duration)


# # tomtom_distance&duration

# In[19]:


tomtom_distance = []
tomtom_duration = []

for index, row in api_input.iterrows():
    tomtom_response = json.loads(row['tomtom_response'])
    tomtom_distance.append(tomtom_response['routes'][0]['summary']['lengthInMeters'])
    tomtom_duration.append(tomtom_response['routes'][0]['summary']['travelTimeInSeconds'])
    
api_input['tomtom_distance'] = pd.Series(tomtom_distance)
api_input['tomtom_duration'] = pd.Series(tomtom_duration)


# # mapbox_distance&duration

# In[20]:


mapbox_distance = []
mapbox_duration = []

for index, row in api_input.iterrows():
    mapbox_response = json.loads(row['mapbox_response'])
    mapbox_distance.append(mapbox_response['routes'][0]['distance'])
    mapbox_duration.append(mapbox_response['routes'][0]['duration'])
    
api_input['mapbox_distance'] = pd.Series(mapbox_distance)
api_input['mapbox_duration'] = pd.Series(mapbox_duration)


# In[21]:


api_input.info()


# # Output

# In[22]:


output = api_input[['origin','destination','nb_request_links','nb_response','tomtom_request_links','tomtom_response','mapbox_request_links','mapbox_response','nb_distance','nb_duration','tomtom_distance','tomtom_duration','mapbox_distance','mapbox_duration']]


# In[24]:


output.to_csv('output.csv', index=False)


# # google_distance&duration

# In[ ]:





# # google_startaddress&endaddress

# In[ ]:




